import { Component } from "ui/Component";
import { IFavoriteContext } from "word/IWordContext";
export class Favorite extends Component<IFavoriteContext> {
    public renderImplementation(): JQuery {
        const $mainContainer = $("<div>");
        $mainContainer.addClass("favorite");
        const $btnFavorite = $("<span>");
        $btnFavorite.addClass("btn");
        const e = this.getValue();
        if (this.getValue().isFavorited(e.word)) {
            $btnFavorite.append("🌟");
        } else {
            $btnFavorite.append("⭐️");
        }
        $mainContainer.append($btnFavorite);
        return $mainContainer;
    }
}