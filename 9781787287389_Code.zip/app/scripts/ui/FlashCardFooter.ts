import { Component } from "ui/Component";
import { IWordContext, IFooterContext } from "word/IWordContext";
export class FlashCardFooter extends Component<IFooterContext>{
    public renderImplementation(): JQuery {
        const data = super.getValue();
        const $mainContainer = $("<div>");
        $mainContainer.addClass("flashcard-footer");

        $mainContainer.append(this.createButton("⬅️", (e) => { this.leftClick(e); }, data.isPreviousButtonEnabled));
        $mainContainer.append(this.createButton("🔘", (e) => { this.middleClick(e); }));
        $mainContainer.append(this.createButton("➡️", (e) => { this.rightClick(e); }, data.isNextButtonEnabled));

        return $mainContainer;
    }

    private leftClick(event: JQueryEventObject): void {
        const data = super.getValue();
        data.previousWord();
    }
    private middleClick(event: JQueryEventObject): void {
        console.log(this);
    }
    private rightClick(event: JQueryEventObject): void {
        const data = super.getValue();
        data.nextWord();
    }

    private createButton(text: string,
        clickHandler: (e: JQueryEventObject) => void,
        isEnabled: boolean = true): JQuery {
        const $container = $("<div>");
        $container.addClass("footer-container-button");
        const $btn = $("<button>");
        $btn.addClass("btn");
        $btn.click((event) => { clickHandler(event); });
        $btn.append(text);
        $btn.prop("disabled", !isEnabled);
        $container.append($btn);
        return $container
    }
}