export abstract class Component<T> {
    private data: T;
    public render(data: T): JQuery {
        this.data = data;
        const result = this.renderImplementation();
        return result;
    }

    protected abstract renderImplementation(): JQuery;

    public getValue(): T {
        return this.data;
    }
}