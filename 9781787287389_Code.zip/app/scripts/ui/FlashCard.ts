import { FlashCardContent } from "FlashCardContent";
import { FlashCardFooter } from "FlashCardFooter";
import { FlashCardHeader } from "FlashCardHeader";
import { Component } from "ui/Component";
import { IWordContext, IHeaderContext, IFooterContext, IFavoriteContext, IFlashCardContext } from "word/IWordContext";
import { IUniqueObject } from "../general/IUniqueObject";
export class FlashCard extends Component<IFlashCardContext> {
    public constructor(
        private header: FlashCardHeader,
        private content: FlashCardContent,
        private footer: FlashCardFooter) {
        super();

    }
    public renderImplementation(): JQuery {
        const data = super.getValue();
        const $mainContainer = $("<div>");
        $mainContainer.addClass("flashcard");
        $mainContainer.append(this.header.render(data));
        $mainContainer.append(this.content.render(data));
        $mainContainer.append(this.footer.render(data));
        return $mainContainer;
    }
}