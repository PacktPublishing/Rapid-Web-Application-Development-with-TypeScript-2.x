import { IWord } from "word/IWord";
import { IImage } from "image/IImage";
export class WordObject implements IWord {
    public id: string;
    public word: string;
    public firstLetter: string;
    public image:IImage;
    public constructor(id: string) {
        this.id = id
    }
}