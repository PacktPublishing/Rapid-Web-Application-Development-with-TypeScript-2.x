import { IUniqueObject } from "general/IUniqueObject";
import { IImage } from "image/IImage";
export interface IWord extends IUniqueObject {
    word: string;
    firstLetter: string;
    image:IImage;
}