import { WordObject } from "word/WordObject";
export class ObjectWithoutSound extends WordObject{
    
}