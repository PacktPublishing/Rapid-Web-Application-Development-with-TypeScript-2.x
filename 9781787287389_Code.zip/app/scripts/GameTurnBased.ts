import { Game } from "Game";
import { IWord } from "word/IWord";
import { IWordContext } from "word/IWordContext";
export class GameTurnBased extends Game {
    constructor() {
        super();
    }
}