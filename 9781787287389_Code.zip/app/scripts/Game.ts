import { IWord } from "word/IWord";
import { IWordContext } from "word/IWordContext";
import { ObjectWithoutSound } from "word/ObjectWithoutSound";
import { Vehicule } from "word/Vehicule";
import * as _ from "lodash";

export class Game {
    protected allWords: IWord[] = [];
    protected currentWordsIndex: number = 0;
    public constructor() {

    }

    private reset = (): void => {
        this.currentWordsIndex = 0;
    }

    public addWord(word: IWord): void {
        if (word instanceof Vehicule) {
            if (word.numberOfWheel < 0) {
                word.numberOfWheel = 0;
            }
        }
        this.allWords.push(word);
    }

    public static getName(): string {
        return Game.toString();
    }

}