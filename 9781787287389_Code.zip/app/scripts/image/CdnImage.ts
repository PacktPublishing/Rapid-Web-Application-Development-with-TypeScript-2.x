import { IImage } from "image/IImage";
export class CdnImage implements IImage {
    public constructor() {
        console.log("CdnImage constructor called");
    }
    public source: string;
    public getBytes(): string {
        return "Source[" + this.source + "] from CDN";
    }
}