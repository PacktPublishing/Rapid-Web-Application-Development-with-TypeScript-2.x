import { IImage } from "image/IImage";
export class ServerImage implements IImage {
    public constructor() {
        console.log("ServerImage constructor called");
    }
    public source: string;
    public getBytes(): string {
        return this.source.toLocaleLowerCase();
    }
}