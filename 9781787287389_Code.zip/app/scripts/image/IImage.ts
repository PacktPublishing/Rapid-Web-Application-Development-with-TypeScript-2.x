import { CdnImage } from "image/CdnImage";
import { ServerImage } from "image/ServerImage";

export interface IImage {
    source: string;
    getBytes: () => string
}
