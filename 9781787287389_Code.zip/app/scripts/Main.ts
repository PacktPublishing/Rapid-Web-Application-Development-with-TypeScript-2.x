﻿import { GameTurnBased } from "GameTurnBased";
import { AppUi } from "ui/AppUi";

const game = new GameTurnBased();
const appUi = new AppUi($("#game-container"), game);